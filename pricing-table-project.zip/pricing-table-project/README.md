# Northstar Pricing Table

A responsive, interactive three-card pricing table built with HTML, CSS, and vanilla JavaScript.

## Features
- Three pricing cards with aligned Header, Price, Feature List, and Action Button sections.
- Highlighted “Most Popular” Pro plan.
- Click-to-select active state with accessible `aria-pressed` values.
- Monthly/yearly billing toggle that updates the displayed prices.
- Responsive layout for mobile and desktop.
- Keyboard-visible focus styles and reduced-motion support.

## Run locally
Open `index.html` in your browser. No build tools or dependencies are required.

## Deploy
1. Create a new GitHub repository and upload `index.html` and `README.md`.
2. For GitHub Pages: open **Settings → Pages**, choose the `main` branch and `/ (root)`, then save.
3. Alternatively, import the repository into Netlify or Vercel and deploy the static site.

After publishing, add your real repository and hosted URLs to your submission.
